"""Test Class."""
# pylint: disable=invalid-name


class TestClass(object):
    def __init__(self):
        ########################################################################
        # TODO:                                                                #
        # Write some message for yourself                                      #
        #                                                                      #
        # Hint: Sometimes we provide some guidelines here.                     #
        ########################################################################
        self.text = 'Replace me...'

        ########################################################################
        #                       END OF YOUR CODE                               #
        ########################################################################

    def write(self):
        print(self.text)

class TestModel(object):
    def return_score(self):
        ########################################################################
        # TODO:                                                                #
        # Give yourself a score                                                #
        #                                                                      #
        # Hint: You pass if you are better than 50                             #
        ########################################################################
        score = 42

        ########################################################################
        #                       END OF YOUR CODE                               #
        ########################################################################

        return score

